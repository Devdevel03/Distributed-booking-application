package gr.opa.booking.android;

public interface SuccessOrFailureHandler
{
    void onSuccess();
    void onFailure();
}
