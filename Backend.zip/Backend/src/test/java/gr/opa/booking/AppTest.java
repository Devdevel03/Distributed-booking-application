package gr.opa.booking;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for simple WorkerApplication.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
