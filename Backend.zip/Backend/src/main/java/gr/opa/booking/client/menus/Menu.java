package gr.opa.booking.client.menus;

import java.io.IOException;

public interface Menu {
    void start() throws IOException, InterruptedException;
}
