package gr.opa.booking.common.models;

public class RoomReservationsCriteria {
    private String managerName;

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }
}
