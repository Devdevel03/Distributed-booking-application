#!/bin/bash

mvn clean compile assembly:single