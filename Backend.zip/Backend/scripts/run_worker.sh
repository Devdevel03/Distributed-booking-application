#!/bin/sh

. "$(dirname "$0")"/base.sh

run_component "$WORKER"
